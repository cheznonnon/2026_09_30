// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




//#define N_GITHUB_REPO


#ifdef N_GITHUB_REPO


#include "../nonnon/bridge/app/hunyapiyo3/hunyapiyo3.c"


#else  // #ifdef N_GITHUB_REPO


#include "../../nonnon/bridge/app/hunyapiyo3/hunyapiyo3.c"


#endif // #ifdef N_GITHUB_REPO

