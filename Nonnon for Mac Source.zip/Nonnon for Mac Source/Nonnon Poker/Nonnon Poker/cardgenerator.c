// Nonnon Freecell
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_PROJECT_CARDGENERATOR
#define _H_NONNON_PROJECT_CARDGENERATOR




//#define N_CARDGENERATOR_DIGIT_PATCH

#include "../../nonnon/bridge/cardgenerator.c"




void
n_cardgenerator_g10( n_bmp *bmp, n_posix_char *str, n_type_gfx size, n_type_gfx sy_others )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.base_color_bg       = n_bmp_black;
	gdi.text_color_main     = n_bmp_white;

	gdi.text_font           = N_CARDGENERATOR_FONT_NAME;
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_MAC_NO_CROP;

	gdi.text_size           = size;

	gdi.text                = n_posix_literal( "1" );
	n_bmp bmp_1; n_bmp_zero( &bmp_1 ); n_gdi_bmp( &gdi, &bmp_1 ); n_gdi_bmp( &gdi, &bmp_1 );

	gdi.text_size           = size - 1;

	//gdi.debug_output        = TRUE;
	gdi.text                = n_posix_literal( "0" );
	n_bmp bmp_0; n_bmp_zero( &bmp_0 ); n_gdi_bmp( &gdi, &bmp_0 ); n_gdi_bmp( &gdi, &bmp_0 );


	n_gdi_crop( &bmp_1, &bmp_1 );
	n_gdi_crop( &bmp_0, &bmp_0 );

//n_bmp_save( &bmp_1, "/Users/nonnon2/Desktop/ret_1.bmp" );
//n_bmp_save( &bmp_0, "/Users/nonnon2/Desktop/ret_0.bmp" );


	n_type_gfx gap = n_gdi_scale_factor;

	n_type_gfx sx = N_BMP_SX( &bmp_1 ) + gap + N_BMP_SX( &bmp_0 );
	n_type_gfx sy = sy_others;

	n_bmp_free( bmp );
	n_bmp_new( bmp, sx, sy );

	n_type_gfx x = 0;
	n_type_gfx y = n_game_centering( sy_others, N_BMP_SY( &bmp_0 ) );

	n_bmp_fastcopy( &bmp_1, bmp, 0,0,N_BMP_SX( &bmp_1 ),N_BMP_SY( &bmp_1 ), x,y ); x += N_BMP_SX( &bmp_1 ) + gap;
	n_bmp_fastcopy( &bmp_0, bmp, 0,0,N_BMP_SX( &bmp_0 ),N_BMP_SY( &bmp_0 ), x,y );

	n_bmp_free_fast( &bmp_1 );
	n_bmp_free_fast( &bmp_0 );


	return;
}




void
n_cardgenerator_init( n_cardgenerator *p, n_type_gfx piles )
{

	// Init

	p->is_init = TRUE;




	p->unit_sx  = 1920 / 17;
	p->unit_sy  = (n_type_gfx) ( (n_type_real) p->unit_sx * 1.5 );
	p->resample = 1.0;

//NSLog( @"%f", p->unit_sx * p->resample );

	p->border = 1;
	p->halo   = 6;


	// Blank Card Maker

	if ( n_cardgenerator_darkmode_is_on() )
	{
		p->color_card_main = n_bmp_rgb(  96, 96, 96 );
	} else {
		p->color_card_main = n_bmp_white;
	}

	{

		const int blend   = 0;// p->option_blend;
		const u32 lighter = n_bmp_rgb( 222,222,222 );

		if ( n_cardgenerator_darkmode_is_on() )
		{
			p->color_frame = n_bmp_rgb( 111,111,111 );
		} else {
			p->color_frame = lighter;
		}

		n_cardgenerator_base( p, &p->bmp_blank, p->color_card_main, blend );
	}

	if ( n_cardgenerator_darkmode_is_on() )
	{
		p->color_margin = n_bmp_alpha_invisible_pixel( p->color_frame );
	} else {
		p->color_margin = n_bmp_white_invisible;
	}


	// Resampling Test

	{
		n_bmp b; n_bmp_carboncopy( &p->bmp_blank, &b );
		n_cardgenerator_resampler( p, &b, p->color_frame );

		p->card_sx = N_BMP_SX( &b );
		p->card_sy = N_BMP_SY( &b );
//n_posix_debug_literal( " %d : %f ", p->card_sx, p->unit_sx * p->resample );

		n_bmp_free_fast( &b );
	}

	p->csx_min = p->csx = p->card_sx * piles;
	p->csy_min = p->csy = p->card_sy * 4;
	p->osy     = (n_type_gfx) ( p->card_sy * 0.18 );


	return;
}

void
n_cardgenerator_loop( n_cardgenerator *p )
{

	// Debug Center

	u32 tick = 0;//n_posix_tickcount();


	if ( p->is_init )
	{
		p->is_init = FALSE;
	} else {
		return;
	}


	// Load

	{
		n_type_gfx size = (n_type_real) p->unit_sx * 0.2;

		n_cardgenerator_gdi( &p->digit_1[  0 ], "A" , size );
		n_cardgenerator_gdi( &p->digit_1[  1 ], "2" , size );
		n_cardgenerator_gdi( &p->digit_1[  2 ], "3" , size );
		n_cardgenerator_gdi( &p->digit_1[  3 ], "4" , size );
		n_cardgenerator_gdi( &p->digit_1[  4 ], "5" , size );
		n_cardgenerator_gdi( &p->digit_1[  5 ], "6" , size );
		n_cardgenerator_gdi( &p->digit_1[  6 ], "7" , size );
		n_cardgenerator_gdi( &p->digit_1[  7 ], "8" , size );
		n_cardgenerator_gdi( &p->digit_1[  8 ], "9" , size );
		n_cardgenerator_g10( &p->digit_1[  9 ], "10", size, N_BMP_SY( &p->digit_1[ 0 ] ) );
		n_cardgenerator_gdi( &p->digit_1[ 10 ], "J" , size );
		n_cardgenerator_gdi( &p->digit_1[ 11 ], "Q" , size );
		n_cardgenerator_gdi( &p->digit_1[ 12 ], "K" , size );
	}

	{
		n_type_gfx size = (n_type_real) p->unit_sx * 0.166;

		n_cardgenerator_gdi( &p->suit__1[ 0 ], "♥", size );
		n_cardgenerator_gdi( &p->suit__1[ 1 ], "♦", size );
		n_cardgenerator_gdi( &p->suit__1[ 2 ], "♠", size );
		n_cardgenerator_gdi( &p->suit__1[ 3 ], "♣", size );
	}

	{
		n_type_gfx size = (n_type_real) p->unit_sx * 0.5;

		n_cardgenerator_gdi( &p->suitbig[ 0 ], "♥", size );
		n_cardgenerator_gdi( &p->suitbig[ 1 ], "♦", size );
		n_cardgenerator_gdi( &p->suitbig[ 2 ], "♠", size );
		n_cardgenerator_gdi( &p->suitbig[ 3 ], "♣", size );
	}

	{
		n_type_gfx size = (n_type_real) p->unit_sx * 0.8;

		u32 fg, bg;
		if ( n_cardgenerator_darkmode_is_on() )
		{
			bg = p->color_card_main;
			fg = n_bmp_blend_pixel( bg, n_bmp_white, 0.5 );
		} else {
			bg = p->color_card_main;
			fg = n_bmp_blend_pixel( bg, n_bmp_black, 0.5 );
		}

		n_cardgenerator_gdi_bg( &p->suit_bg[ 0 ], "♥", size, bg, fg );
		n_cardgenerator_gdi_bg( &p->suit_bg[ 1 ], "♦", size, bg, fg );
		n_cardgenerator_gdi_bg( &p->suit_bg[ 2 ], "♠", size, bg, fg );
		n_cardgenerator_gdi_bg( &p->suit_bg[ 3 ], "♣", size, bg, fg );
	}

	{
		n_mac_image_rc_load_bmp( @"256/neko"   , &p->bmp_logo    );
		n_mac_image_rc_load_bmp( @"256/crown_k", &p->bmp_crown_k );
		n_mac_image_rc_load_bmp( @"256/crown_q", &p->bmp_crown_q );
//n_bmp_save( &p->bmp_logo, "/Users/nonnon2/Desktop/ret.bmp" );

		n_type_real ratio = (n_type_real) p->unit_sx / N_BMP_SX( &p->bmp_logo ) * 0.5;
//NSLog( @"%f", ratio );

		if ( ratio < 0.5 )
		{
			int i = 0;
			int c = 1.0 / ratio;
			n_posix_loop
			{
				n_bmp_flush_antialias( &p->bmp_logo   , 1.0 );
				n_bmp_flush_antialias( &p->bmp_crown_k, 1.0 );
				n_bmp_flush_antialias( &p->bmp_crown_q, 1.0 );

				i++;
				if ( i >= c ) { break; }
			}
		}

		n_bmp_resampler( &p->bmp_logo   , ratio, ratio );
		n_bmp_resampler( &p->bmp_crown_k, ratio, ratio );
		n_bmp_resampler( &p->bmp_crown_q, ratio, ratio );
	}


	// Cat

	if ( 0 )
	{
		//
	} else
	if ( n_cardgenerator_darkmode_is_on() )
	{
		n_bmp_flush_replacer( &p->bmp_logo, n_bmp_argb(  64, 10, 10, 10 ), n_bmp_argb(  64, 10, 10, 10 ) );
		n_bmp_flush_replacer( &p->bmp_logo, n_bmp_argb( 128, 10, 10, 10 ), n_bmp_argb( 128, 10, 10, 10 ) );
	} else {
		n_bmp_flush_replacer( &p->bmp_logo, n_bmp_argb(  64,128,128,128 ), n_bmp_argb(  64,255,255,255 ) );
		n_bmp_flush_replacer( &p->bmp_logo, n_bmp_argb( 128,128,128,128 ), n_bmp_argb( 128,255,255,255 ) );
	}


	// Suit Mark and Digit Maker

//if(0)
	{

		n_type_gfx i = 0;
		n_posix_loop
		{
			n_bmp_carboncopy( &p->digit_1[ i ], &p->digit_2[ i ] );

			n_bmp_flush_mirror( &p->digit_2[ i ], N_BMP_COPY_MIRROR_ROTATE180 );

			i++;
			if ( i >= N_CARDGENERATOR_CARD_UNIT ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_bmp_carboncopy( &p->suit__1[ i ], &p->suit__2[ i ] );

			n_bmp_flush_mirror( &p->suit__2[ i ], N_BMP_COPY_MIRROR_ROTATE180 );

			i++;
			if ( i >= N_CARDGENERATOR_SUIT_MAX ) { break; }
		}

	}


	// Halo Maker : new card size is needed

	n_cardgenerator_dropshadow( &p->bmp_halo, p->card_sx, p->card_sy, p->halo, 1 );


	// Preload

	{

		BOOL p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = TRUE;

/*
		// [x] : broken image will be made

		dispatch_group_t group = dispatch_group_create();
		dispatch_queue_t queue = dispatch_get_main_queue();

		dispatch_async( queue, ^{ n_cardgenerator_card( p, 0 ); } );
		dispatch_async( queue, ^{ n_cardgenerator_card( p, 1 ); } );
		dispatch_async( queue, ^{ n_cardgenerator_card( p, 2 ); } );
		dispatch_async( queue, ^{ n_cardgenerator_card( p, 3 ); } );

		dispatch_group_notify( group, queue, ^{ ; } );
		dispatch_group_wait( group, DISPATCH_TIME_FOREVER );
*/

		NSOperationQueue *q = [[NSOperationQueue alloc] init];

		int i = 0;
		n_posix_loop
		{
			NSOperation *o = [NSBlockOperation blockOperationWithBlock:^{
				n_cardgenerator_card( p, i );
			}];

			[q addOperation:o];

			i++;
			if ( i >= 4 ) { break; }
		}

		[q waitUntilAllOperationsAreFinished];


		n_bmp_is_multithread = p_multithread;

	}


	if ( tick ) { n_posix_debug_literal( "%d", (int) n_posix_tickcount() - tick ); }


	return;
}


#endif // _H_NONNON_PROJECT_CARDGENERATOR

